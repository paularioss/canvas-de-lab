﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T1___PR_2431922
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Mi segundo programa");
            Console.WriteLine("ingresar nombre");
            string sNombre = Console.ReadLine();
            Console.WriteLine("inresar edad");
            string sEdad = Console.ReadLine();
            Console.WriteLine("ingresar carrera");
            string sCarrera = Console.ReadLine();
            Console.WriteLine("ingresar carnet");
            string sCarnet = Console.ReadLine();

            Console.Write("soy " + sNombre + ","+ " tengo "+ sEdad + " años y estudio la carrera de "+ sCarrera + ". "+ "mi número de carné es "+ sCarnet);
            Console.ReadKey();
        }
    }
}
