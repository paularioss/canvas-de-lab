﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L1___PR_2431922
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hola Mundo soy Paula Rios");
            Console.ReadKey();

            /*la unica diferencia es que uno lleva más código que el otro pero el resultado es el mismo*/
            Console.Write("Hola Mundo");
            Console.Write("Soy Paula");
            Console.ReadKey();

            Console.WriteLine("Ingrese su nombre:");
            String Nombre = Console.ReadLine();

            Console.WriteLine("Hola Mundo");
            Console.WriteLine("soy" + Nombre);

            /*la diferencia*/
            Console.WriteLine("Hola Mundo");
            Console.WriteLine("soy" + Nombre);
            Console.ReadKey();
        }
    }
}
