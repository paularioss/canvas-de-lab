﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace reto2_semana3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("reto 2 semana 3 Paula Rios 2431922 - Ashley Juárez - Paula Morales");
            int[] niveles;
            niveles = new int[5];
            int[] niños;
            niños = new int[5];
            int[] adultos;
            adultos = new int[5];
            string[] responsable;
            responsable=new string[5];
            int i;
       


            for (i = 0; i < 5; i++)
            {
                Console.WriteLine("¿Cuantas personas viven en el nivel? " + (i + 1));
                niveles[i] = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("¿Cuántos niños viven en el nivel? " + (i + 1));
                niños[i] = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("¿Cuántos adultos viven en el nivel" + (i + 1));
                adultos[i] = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Quién es el responsable del nivel"+(i + 1));
                responsable[i] = Console.ReadLine();
            }



                for (i = 0; i < 5; i++)
                {
                    Console.WriteLine("viven " + niveles[i] + "  personas en el nivel  " + (i + 1));
                    Console.WriteLine("Viven " + niños[i] + " niños en el nivel " + (i + 1));
                    Console.WriteLine("viven " + adultos[i] + " adultos en el nivel " + (i + 1));
                }


          
             
            
            for (i = 0; i < 5; i++)
            {
                Console.WriteLine("viven " + adultos[i] + " adultos en el nivel " + (i + 1));
            }

            int max = -100000;
            int mmax = 0;
            string respon = "";
            for (i = 0; i < 5; i++)
            {
                if (niveles[i] > max)
                {
                    max = niveles[i];
                    mmax = (i + 1);
                    respon = responsable[i];
                    
                }
            }

            Console.WriteLine("el nivel " + mmax + " cuenta con más niños: " + max + " niños. y atiende el responsable:" +respon);



            Console.ReadKey();
        }
    }
}
