﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L10_PMRSS_2431922
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int canti = 0;
            int contador = 0;
            string usuario;
            string contraseña;
            bool respuesta=false;

            while (canti <= 3 )
            {
                Console.WriteLine("ingrese su usuario");
                usuario = Console.ReadLine();
                Console.WriteLine("ingrese su contraseña");
                contraseña = Console.ReadLine();

                respuesta = login(usuario, contraseña);



                if (respuesta == true)
                {
                    canti = 3;
                    Console.WriteLine("se ingresó correctamente");
                }
                else 
                {
                    Console.WriteLine("error, ingrese de nuevo, cantidad de intentos: "+ contador
                        );
                    contador++;
                    canti++;

                    
                }


            }
            Console.WriteLine("se ha caducado");
            Console.ReadKey();
        }
        public static bool login(string user,string pass)
        {
            if (user == "usuario1" && pass == "asdasd")
            {
                return true;
            }
            else
            {
                return false;

            }
            
        }
    }
}
