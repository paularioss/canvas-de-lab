﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L11_PPMRS_2431922
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[] aseccion;
            aseccion = new double[5]; 
            double[] bseccion;
            bseccion = new double[5];


            Console.WriteLine("ingrese las notas de la seccion a");
     
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine(" ingrese nota a " + (i+1));
                aseccion[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("ingrese las notas de la seccion b");
            for (int i = 0; i < 5; i++)
            {

                Console.WriteLine(" ingrese nota a " + (i + 1));
                aseccion[i] = Convert.ToInt32(Console.ReadLine());
            }
        int contador1=0;
        int contador2=0;
            double total=0;
            for (int i = 0; i < 5; i++)
            {
                total = total+ aseccion[i];
             if (aseccion[i] >= 65)
                {
                    contador1++;
                }
             else
                {
                    contador2++;
                }

            }
            double porcentajeaa = (Convert.ToDouble(contador1) * 100) / 5;
            double porcentajeab = (Convert.ToDouble(contador2) * 100) / 5; 
            Console.WriteLine("el pporcentaje que aprobó de la sección a es de: "+ porcentajeaa);
            Console.WriteLine("el porcentaje de desaprobados es:" + porcentajeab);

            int contador3=0;
            int contador4 = 0;
            double totalb = 0;
            for (int i = 0; i < 5; i++)
            {
                totalb = totalb+ bseccion[i];
                if(bseccion[i] >=65 )
                {
                    contador3++;
                }
                else
                {
                    contador4++;
                }
            }
            double porcentajeba = (Convert.ToDouble(contador3) * 100) / 5;
            double porcentajebb = (Convert.ToDouble(contador4) * 100) / 5;

            double suma1 = (Convert.ToDouble(contador1) + Convert.ToDouble(contador3) / 10);
            Console.WriteLine("el porcentaje total de aprobados es de: " + suma1);

            double suma2 = (Convert.ToDouble(contador2) + Convert.ToDouble(contador4) / 10); 
            Console.WriteLine (" el porcentaje total de desaprobados es de " + suma2);

            double promedio = (total / 5);
            double promediob = (totalb / 5);
            Console.WriteLine("el promedio de notas de la sección a es: " + total);
            Console.WriteLine("el promedio de notas de la sección b es: " + totalb);

            double promediot = ((total + totalb) / 10);
            Console.WriteLine("el promedio total es de " + promediot);

            int c90a = 0;
            int c75a = 0;
            int c90b = 0;
            int c75b = 0;
            int c90 = 0;
            int c75 = 0;
            for (int i = 0; i < 5; i++)
            {
                if (aseccion[i]>90)
                {
                    c90a++;
                }
                if (bseccion[i]>90)
                { 
                    c90b++;
                }

            }

            for (int i = 0; i < 5; i++)
            {
                if (aseccion[i] < 75)
                {
                    c75a++;
                }
                if (bseccion[i] < 75)
                {
                    c75b++;
                }

            }
            c90 = c90a + c90b;
            Console.WriteLine("estudiantes con notas arriba de 90 es de " + c90);
            c75 = c75a + c75b;
            Console.WriteLine(" estudiantes con notas abajo de 75 es de " + c75);











            Console.ReadKey();

        }
    }
}
