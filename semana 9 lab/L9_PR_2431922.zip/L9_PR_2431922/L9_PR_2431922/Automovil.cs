﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L9_PR_2431922
{
    internal class Automovil
    {
        private int modelo  ;
        private double precio ;
        private string marca ;
        private bool disponible  ;
        private double tipoCambioDolar ;
        private double descuentoAplicado ;

        public Automovil()
        {
            this.modelo = 2019;
            this.precio = 10000.00;
            this.marca = "";
            this.disponible = false;
            this.tipoCambioDolar = 7.50;
            this.descuentoAplicado = 0.00;
        }
        public void definirModelo (int unmodelo)
        {
        this.modelo = unmodelo;
        }
        public void definirPrecio(double unprecio)
        {
            this.precio = unprecio; 
        }
        public void DefinirunaMarca( string  unMarca)
        {
            this.marca = unMarca;
        }
        public void definiruntipoCambio(double untipocambio)
        {
           this.tipoCambioDolar = untipocambio; 
        }
        public double Preciodolares()
        {
            double preciodolar = 0;
            preciodolar = this.precio / this.tipoCambioDolar;
            return preciodolar;
        }
        public void CambiarDisponibilidad()
        {
            if (disponible == true)
            {
                disponible = false;
            }
            else
            {
                disponible = true;
            }
        }
        public string MostrarDisponibilidad()
        {
            string texto = "";
            if (disponible == true)
            {
                texto = (" se ecuentra disponible ");
            }
            else
            {
                texto = ("no se enucentra disponible");
            }
            return texto;
        }
        public string MostrarInformacion()
        {
            string
            return this.marca;
        }
        public void setAplicarDescuento(double lo) 
        {
            this.descuentoAplicado = lo;
        }
    }

}
