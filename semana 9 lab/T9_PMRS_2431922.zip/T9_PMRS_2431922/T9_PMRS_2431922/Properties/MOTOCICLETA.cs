﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T9_PMRS_2431922.Properties
{
    internal class MOTOCICLETA
    {
    }
}
