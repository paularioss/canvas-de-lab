﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L12_PMRS_2431922
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[,] elementos = new double[4,5];
            double[,] matriz = new double[4, 5];
            double[,] sum = new double[4, 5];
            double acu1 = 0;
            double cont1 = 0;
            double promedio;
            Random rand = new Random();

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 5; j++)
                {

                    elementos[i, j] = rand.Next(100);
                    acu1 = acu1 + elementos[i, j];
                    cont1++;

                }
            }
                promedio = acu1 / cont1;
            Console.WriteLine("EJERCICIO1");
            Console.WriteLine(" suma de la primera matriz " + acu1);
            Console.WriteLine(" promedio de la matriz " + promedio);

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 5; j++)
                {
 
                    matriz[i, j] = rand.Next(100);
                 

                }
            }
            Console.WriteLine("EJERCICIO2");

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    sum[i,j] = matriz[i,j] + elementos[i,j];
                    Console.WriteLine("fila  "+i +" columna " +j);
                }
            }
            Console.ReadKey();
        }
    }
}
